To run this test:

* build the zyre.node binding using build.sh (in parent directory)
- copy ../build/Release/zyre.node into node_modules/

