Linux
-----

./autogen.sh
./configure
make && make check
make install

Others
------
[OS specific](https://github.com/zeromq/zyre/tree/master/builds/)