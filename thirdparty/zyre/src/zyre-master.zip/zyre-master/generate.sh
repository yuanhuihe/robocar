#!/usr/bin/env sh

set -e

gsl project.xml

chmod +x autogen.sh version.sh
